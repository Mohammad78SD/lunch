from django.conf import settings
from ippanel import Client, Error, HTTPError, ResponseCode

def send_otp(phone_number, otp):
    
    client = Client("8en9TUYaGHPVU-gCdUSCCe4XxHuZhZUp62SQTIkY7ho=")
    ptrn = {
        'code': otp
        }

    client.send_pattern('zz9qp2vzfbtairt', "+983000505", str(phone_number), ptrn)
        
    return True

def send_sms(phone_number, message):
    client = Client("8en9TUYaGHPVU-gCdUSCCe4XxHuZhZUp62SQTIkY7ho=")
    print(client.send('+983000505', [phone_number], message, 'MetafanLunch'))