from django.contrib import admin
from lunch.models import Lunch, CustomUser

admin.site.register(Lunch)
admin.site.register(CustomUser)
