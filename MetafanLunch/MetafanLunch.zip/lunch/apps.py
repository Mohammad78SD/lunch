from django.apps import AppConfig


class LunchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lunch'
